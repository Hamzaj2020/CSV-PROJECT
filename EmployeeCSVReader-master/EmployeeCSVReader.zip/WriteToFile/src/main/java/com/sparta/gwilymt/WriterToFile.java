package com.sparta.gwilymt;
import java.io.*;
import java.util.ArrayList;

public class WriterToFile {
    public static void writeToCleanFile(DataHolder employees, String file){
        try{
            Employee entry;
            FileWriter writer = new FileWriter("C:\\Users\\Gwilym Turner\\Documents\\Mini Project\\" + file);
            for (Employee emp : employees.list)
            {
                entry = emp;
                writer.write(entry.getId()+", "+entry.getTitle()+" "+entry.getFirstName()+" "+entry.getMiddleInitial()+" "+entry.getLastName()+", "+entry.getGender()+", "+entry.getEmail()+", "+entry.getDateOfBirth()+", "+entry.getJoinDate()+", "+entry.getSalary()+ "\n");
            }
            writer.close();
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
            System.out.println(e.getMessage());
        }
        catch (IOException e) {
            e.printStackTrace();
            System.out.println(e.getMessage());
        }
    }
    public static void writeToDirtyFile(DataHolder employees, String file){
        try{
            DirtyData entry;
            FileWriter writer = new FileWriter("C:\\Users\\Gwilym Turner\\Documents\\Mini Project\\" + file);
            for (Employee emp : employees.list)   
            {
                entry =(DirtyData) emp;
                writer.write(entry.getId()+", "+entry.getTitle()+" "+entry.getFirstName()+" "+entry.getMiddleInitial()+" "+entry.getLastName()+", "+entry.getGender()+", "+entry.getEmail()+", "+entry.getDateOfBirth()+", "+entry.getJoinDate()+", "+entry.getSalary()+ ", "+entry.getErrorMessage()+"\n");
            }
            writer.close();
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
            System.out.println(e.getMessage());
        }
        catch (IOException e) {
            e.printStackTrace();
            System.out.println(e.getMessage());
        }
    }
}
