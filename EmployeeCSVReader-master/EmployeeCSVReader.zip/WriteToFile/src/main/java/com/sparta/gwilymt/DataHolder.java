package com.sparta.gwilymt;

import java.util.ArrayList;

public class DataHolder {
    ArrayList<Employee> list = new ArrayList<>();

    public void addToList(Employee employee){
        list.add(employee);
    }
    public boolean searchById(int id){
        for(Employee emp : list){
            if (emp.getId() == id){
                System.out.println("Employee found with matching ID: ");
                System.out.println(emp.getId()+", "+emp.getTitle()+" "+emp.getFirstName()+" "+emp.getMiddleInitial()+" "+emp.getLastName()+", "+emp.getGender()+", "+emp.getEmail()+", "+emp.getDateOfBirth()+", "+emp.getJoinDate()+", "+emp.getSalary());
                return true;
            }
        }
        System.out.println("No employee with matching ID was found.");
        return false;
    }
}
